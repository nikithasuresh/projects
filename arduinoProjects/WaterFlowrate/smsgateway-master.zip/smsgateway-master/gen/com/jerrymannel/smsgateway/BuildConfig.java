/** Automatically generated file. DO NOT MODIFY */
package com.jerrymannel.smsgateway;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}